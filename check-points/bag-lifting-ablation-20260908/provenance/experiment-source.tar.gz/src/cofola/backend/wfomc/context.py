"""WFOMC context for encoding combinatorics problems.

This module provides Context, the mutable state used while translating a
planning Problem and AnalysisResult into a WFOMC problem.
"""
from __future__ import annotations

from typing import Any, TypeAlias

from cofola.backend.wfomc.api import (
    Const,
    EncodedProblem,
    EvidenceFormula,
    Formula,
    Pred,
    Rational,
    build_problem,
    evidence_parts,
    normalize_sentence,
    parse,
    top,
)

Expr: TypeAlias = Any

from loguru import logger

from cofola.backend.wfomc.utils import create_aux_pred, create_cofola_pred, create_cofola_var
from cofola.backend.wfomc.decoder import Decoder

from cofola.frontend.problem import Problem
from cofola.frontend.objects import PartDef, SequenceDef
from cofola.planing.analysis.entities import AnalysisResult
from cofola.frontend.objects import ObjRef, Entity as IREntity


class Context:
    """Context for encoding a planning problem to a WFOMC problem.

    Holds all state built up during object/constraint encoding,
    then produces an (EncodedProblem, Decoder) pair via build().

    Attributes:
        problem: The immutable planning Problem being encoded.
        analysis: Analysis result (SetInfo/BagInfo per ObjRef).
        singletons: Entities that are always singletons (from analysis).
        domain: WFOMC domain constants (one Const per entity).
        sentence: The accumulated FO sentence (conjunction of all sub-sentences).
        weighting: WFOMC weighting map (Pred → (pos_weight, neg_weight)).
        unary_evidence: Unary ground atoms (e.g., p_A(c_a)).
        overcount: Rational overcounting correction factor (for partitions etc.).
        validator: List of (Expr, Expr) tuples for Decoder validation.
        indis_vars: List of symbolic vars for indistinguishable-entity decoding.
        gen_vars: List of all generated symbolic vars (for Decoder).
        ref2pred: Maps ObjRef → WFOMC Pred (the predicate representing that object).
        ref_entity2pred: Maps (ObjRef | None, IREntity) → Pred
            (entity-specific predicates).
        ref2var: Maps ObjRef → symbolic Expr (for size constraints).
        ref_entity2var: Maps (ObjRef, IREntity) → symbolic Expr (bag entity vars).
        ref_mul2var: Maps (ObjRef, int) → symbolic Expr (indis-entity multiplicity vars).
        used_refs: Set of ObjRef whose predicates are actually used in the sentence.
        sequence_ref: ObjRef of the unique SequenceDef, or None if no sequence.
        leq_pred: Global 'LEQ' binary predicate (linear order).
        pred_pred: Global 'PRED' binary predicate (predecessor for linear sequences).
    """

    def __init__(self, problem: Problem, analysis: AnalysisResult) -> None:
        """Initialise the encoding context.

        Args:
            problem: The immutable planning Problem to encode.
            analysis: The entity analysis result for this problem.
        """
        self.problem: Problem = problem
        self.analysis: AnalysisResult = analysis

        self.singletons: frozenset[IREntity] = frozenset(analysis.singletons)
        self.domain: set[Const] = {Const(e.name) for e in analysis.all_entities}

        # Accumulated WFOMC components
        self.sentence: Formula = top
        self.weighting: dict[Pred, tuple] = {}
        self.unary_evidence: set[EvidenceFormula] = set()
        self.overcount: Rational = Rational(1, 1)
        self.validator: list = []
        self.indis_vars: list = []
        self.gen_vars: list = []

        # ObjRef → WFOMC Pred (main predicate for each object)
        self.ref2pred: dict[ObjRef, Pred] = {}
        # (ObjRef | None, IREntity) → Pred  (entity-specific predicates)
        self.ref_entity2pred: dict[tuple[ObjRef | None, IREntity], Pred] = {}
        # ObjRef → symbolic Expr  (for size-constraint variables)
        self.ref2var: dict[ObjRef, Expr] = {}
        # (ObjRef, IREntity) → Expr  (per-entity multiplicity variables)
        self.ref_entity2var: dict[tuple[ObjRef, IREntity], Expr] = {}
        # (ObjRef, int multiplicity) → Expr  (indistinguishable-entity variables)
        self.ref_mul2var: dict[tuple[ObjRef, int], Expr] = {}
        # Set of ObjRef whose predicates are referenced in self.sentence
        self.used_refs: set[ObjRef] = set()

        # Find the unique SequenceDef, if any (at most one per problem after lowering)
        self.sequence_ref: ObjRef | None = self._find_sequence_ref()
        self.ref2leq_pred: dict[ObjRef, Pred] = {}
        self.ref2lt_pred: dict[ObjRef, Pred] = {}
        self.ref2predecessor_pred: dict[ObjRef, Pred] = {}
        self.ref2next_to_pred: dict[ObjRef, Pred] = {}

        # Global linear-order / predecessor predicates (shared by all sequences)
        self.leq_pred: Pred = Pred('LEQ', 2)
        self.pred_pred: Pred = Pred('PRED', 2)

        # Singletons predicate (set during _encode_singleton if singletons exist)
        self.singletons_pred: Pred | None = None

        # Cache: ObjRef → bag_singletons_pred (created lazily in _get_bag_size_expr)
        self.ref2bag_singletons_pred: dict[ObjRef, Pred] = {}

    # =========================================================================
    # Setup helpers
    # =========================================================================

    def _find_sequence_ref(self) -> ObjRef | None:
        """Return the ObjRef of the first SequenceDef, or None."""
        sequence_refs = []
        for ref in self.problem.refs():
            defn = self.problem.get_object(ref)
            if isinstance(defn, SequenceDef):
                sequence_refs.append(ref)
        if len(sequence_refs) > 1:
            raise ValueError(
                "WFOMC backend expects at most one sequence object per component"
            )
        return sequence_refs[0] if sequence_refs else None

    # =========================================================================
    # Pred management
    # =========================================================================

    def get_pred(
        self,
        ref: ObjRef,
        *,
        create: bool = False,
        use: bool = True,
    ) -> Pred:
        """Get (or optionally create) the WFOMC predicate for an object reference.

        The predicate name is derived from problem.get_name(ref) via _obj_pred_name().
        Arity is always 1 (unary predicate over the domain).

        Args:
            ref: The object reference.
            create: If True, create the predicate if it doesn't exist yet.
            use: If True, mark this ref as used (affects evidence pruning).

        Returns:
            The Pred for this object.

        Raises:
            ValueError: If not found and create=False.

        IMPLEMENTATION:
            - If ref not in self.ref2pred and create: create with _obj_pred_name(ref), arity=1
            - If ref not in self.ref2pred and not create: raise ValueError
            - If use: self.used_refs.add(ref)
            - Return self.ref2pred[ref]
        """
        if ref not in self.ref2pred:
            if create:
                self.ref2pred[ref] = create_cofola_pred(self._obj_pred_name(ref), 1)
            else:
                raise ValueError(f"No predicate for ref {ref} (id={ref.id})")
        if use:
            self.used_refs.add(ref)
        return self.ref2pred[ref]

    def set_pred(self, ref: ObjRef, pred: Pred) -> None:
        """Explicitly assign a Pred to a ref (used when encoder creates preds directly).

        Args:
            ref: The object reference.
            pred: The predicate to assign.
        """
        self.ref2pred[ref] = pred

    def get_entity_pred(self, ref: ObjRef, entity: IREntity) -> Pred:
        """Get (or create) the entity-specific predicate for (ref, entity).

        Used for bag encoding where each entity in a bag gets its own predicate.
        Name: '<obj_name>_<entity_name>' with cofola prefix.

        Args:
            ref: The bag object reference.
            entity: The entity.

        Returns:
            The entity-specific Pred.

        IMPLEMENTATION:
            key = (ref, entity)
            If not in ref_entity2pred: create Pred with name _entity_pred_name(ref, entity), arity=1
            Return ref_entity2pred[key]
        """
        key = (ref, entity)
        if key not in self.ref_entity2pred:
            self.ref_entity2pred[key] = create_cofola_pred(
                self._entity_pred_name(ref, entity), 1
            )
        return self.ref_entity2pred[key]

    # =========================================================================
    # Var management
    # =========================================================================

    def get_obj_var(self, ref: ObjRef, *, set_weight: bool = True) -> Expr:
        """Get (or create) the symbolic variable for an object (for size constraints).

        If set_weight=True, also configures self.weighting[pred] = (var, 1).

        Args:
            ref: The object reference.
            set_weight: Whether to register the variable as a WFOMC weight.

        Returns:
            The symbolic Expr for this object's size variable.

        IMPLEMENTATION:
            If ref not in ref2var: create var with name from _obj_var_name(ref)
            If set_weight: pred = get_pred(ref); self.weighting[pred] = (ref2var[ref], 1)
            Return ref2var[ref]
        """
        if ref not in self.ref2var:
            self.ref2var[ref] = self.create_var(self._obj_var_name(ref))
        if set_weight:
            pred = self.get_pred(ref)
            self.weighting[pred] = (self.ref2var[ref], 1)
        return self.ref2var[ref]

    def get_entity_var(
        self,
        ref: ObjRef,
        entity: IREntity | None = None,
    ) -> Expr | dict[IREntity, Expr]:
        """Get (or create) the symbolic variable for an entity within a bag object.

        Used for bag multiplicity encoding. If entity is None, returns the full
        per-entity dict for this ref.

        Args:
            ref: The bag object reference.
            entity: The entity, or None to get the full dict.

        Returns:
            The symbolic Expr if entity is given, else dict[IREntity, Expr].

        IMPLEMENTATION:
            If entity is None: return {e: v for (r,e),v in ref_entity2var.items() if r==ref}
            key = (ref, entity)
            If not in ref_entity2var: create var with _entity_var_name(ref, entity)
            Return ref_entity2var[key]
        """
        if entity is None:
            return {e: v for (r, e), v in self.ref_entity2var.items() if r == ref}
        key = (ref, entity)
        if key not in self.ref_entity2var:
            self.ref_entity2var[key] = self.create_var(self._entity_var_name(ref, entity))
        return self.ref_entity2var[key]

    def get_size_expr(self, ref: ObjRef) -> "Expr | int":
        """Return the size expression for an object.

        If the object has a known exact_size in the analysis, returns the integer
        directly (no WFOMC variable created).  Otherwise falls back to get_obj_var()
        to create/reuse a polynomial variable.

        Args:
            ref: The object reference.

        Returns:
            A plain Python int if exact_size is known, else a symbolic Expr.
        """
        info = self.analysis.set_info.get(ref) or self.analysis.bag_info.get(ref)
        if info is not None and info.exact_size is not None:
            return info.exact_size
        return self.get_obj_var(ref)

    def get_indis_entity_var(
        self,
        ref: ObjRef,
        multiplicity: int | None = None,
    ) -> Expr | dict[int, Expr]:
        """Get (or create) the symbolic variable for indistinguishable entities.

        Used when multiple entities in a bag are indistinguishable (same multiplicity).
        If multiplicity is None, returns the full dict for this ref.

        Args:
            ref: The bag object reference.
            multiplicity: The shared multiplicity, or None for the full dict.

        Returns:
            The symbolic Expr if multiplicity given, else dict[int, Expr].

        IMPLEMENTATION:
            If multiplicity is None: return {m:v for (r,m),v in ref_mul2var.items() if r==ref}
            key = (ref, multiplicity)
            If not in ref_mul2var: create var with _indis_var_name(ref, multiplicity)
            Return ref_mul2var[key]
        """
        if multiplicity is None:
            return {m: v for (r, m), v in self.ref_mul2var.items() if r == ref}
        key = (ref, multiplicity)
        if key not in self.ref_mul2var:
            self.ref_mul2var[key] = self.create_var(self._indis_var_name(ref, multiplicity))
        return self.ref_mul2var[key]

    # =========================================================================
    # Sequence-specific predicates
    # =========================================================================

    def get_leq_pred(self, seq_ref: ObjRef) -> Pred:
        """Get the sequence-restricted LEQ predicate for a SequenceDef.

        Creates a new binary predicate `<seq_name>_LEQ` and adds a sentence:
            ∀X∀Y: (seq_LEQ(X,Y) ↔ (source_pred(X) ∧ source_pred(Y) ∧ LEQ(X,Y)))
        where source_pred is the predicate for the sequence's source.

        Args:
            seq_ref: ObjRef of the SequenceDef.

        Returns:
            The sequence-restricted LEQ Pred.

        IMPLEMENTATION:
            defn = problem.get_object(seq_ref)  # SequenceDef
            source_pred = get_pred(defn.source)
            leq_name = f"{_get_name(seq_ref)}_LEQ"
            leq_pred = create_pred(leq_name, 2)
            Add to self.sentence: ∀X∀Y: (leq_pred(X,Y) <-> (source_pred(X) & source_pred(Y) & self.leq_pred(X,Y)))
            Return leq_pred
        """
        if seq_ref in self.ref2leq_pred:
            return self.ref2leq_pred[seq_ref]
        defn = self.problem.get_object(seq_ref)
        domain_pred = self.get_pred(defn.flatten if defn.flatten is not None else defn.source)
        leq_name = f"{self._get_name(seq_ref)}_LEQ"
        leq_pred = self.create_pred(leq_name, 2)
        self.sentence = self.sentence & parse(
            f"\\forall X: (\\forall Y: ({leq_pred}(X,Y) <-> "
            f"({domain_pred}(X) & {domain_pred}(Y) & {self.leq_pred}(X,Y))))"
        )
        self.ref2leq_pred[seq_ref] = leq_pred
        return leq_pred

    def get_predecessor_pred(self, seq_ref: ObjRef) -> Pred:
        """Get the sequence-restricted PRED predicate for a SequenceDef.

        Creates:
            ∀X∀Y: (seq_PRED(X,Y) ↔ (source_pred(X) ∧ source_pred(Y) ∧ PRED(X,Y)))

        Args:
            seq_ref: ObjRef of the SequenceDef.

        Returns:
            The sequence-restricted predecessor Pred.

        IMPLEMENTATION:
            defn = problem.get_object(seq_ref)  # SequenceDef
            source_pred = get_pred(defn.source)
            seq_pred_name = f"{_get_name(seq_ref)}_PRED"
            Create pred and add sentence as with get_leq_pred but using pred_pred.
        """
        if seq_ref in self.ref2predecessor_pred:
            return self.ref2predecessor_pred[seq_ref]
        defn = self.problem.get_object(seq_ref)
        domain_pred = self.get_pred(defn.flatten if defn.flatten is not None else defn.source)
        seq_pred_name = f"{self._get_name(seq_ref)}_PRED"
        seq_pred = self.create_pred(seq_pred_name, 2)
        self.sentence = self.sentence & parse(
            f"\\forall X: (\\forall Y: ({seq_pred}(X,Y) <-> "
            f"({domain_pred}(X) & {domain_pred}(Y) & {self.pred_pred}(X,Y))))"
        )
        self.ref2predecessor_pred[seq_ref] = seq_pred
        return seq_pred

    def get_lt_pred(self, seq_ref: ObjRef) -> Pred:
        """Get the strict sequence order predicate for a SequenceDef.

        The global LEQ predicate is reflexive. Pattern constraints use strict
        before semantics, so LT(X,Y) is derived from the sequence-restricted
        order by excluding the reverse order.
        """
        if seq_ref in self.ref2lt_pred:
            return self.ref2lt_pred[seq_ref]

        leq_pred = self.get_leq_pred(seq_ref)
        lt_name = f"{self._get_name(seq_ref)}_LT"
        lt_pred = self.create_pred(lt_name, 2)
        self.sentence = self.sentence & parse(
            f"\\forall X: (\\forall Y: ({lt_pred}(X,Y) <-> "
            f"({leq_pred}(X,Y) & ~{leq_pred}(Y,X))))"
        )
        self.ref2lt_pred[seq_ref] = lt_pred
        return lt_pred

    def get_next_to_pred(self, seq_ref: ObjRef) -> Pred:
        """Get the NEXT_TO predicate for a SequenceDef.

        next_to(X,Y) ↔ pred(X,Y) ∨ pred(Y,X)

        Args:
            seq_ref: ObjRef of the SequenceDef.

        Returns:
            The next-to Pred.

        IMPLEMENTATION:
            pred_pred = get_predecessor_pred(seq_ref)
            next_to_pred = create_pred(f"{_get_name(seq_ref)}_NEXT_TO", 2)
            Add sentence: ∀X∀Y: (next_to(X,Y) <-> (pred(X,Y) | pred(Y,X)))
            Return next_to_pred
        """
        if seq_ref in self.ref2next_to_pred:
            return self.ref2next_to_pred[seq_ref]
        pred_pred = self.get_predecessor_pred(seq_ref)
        next_to_name = f"{self._get_name(seq_ref)}_NEXT_TO"
        next_to_pred = self.create_pred(next_to_name, 2)
        self.sentence = self.sentence & parse(
            f"\\forall X: (\\forall Y: ({next_to_pred}(X,Y) <-> "
            f"({pred_pred}(X,Y) | {pred_pred}(Y,X))))"
        )
        self.ref2next_to_pred[seq_ref] = next_to_pred
        return next_to_pred

    # =========================================================================
    # Utility
    # =========================================================================

    def get_parts_of(self, partition_ref: ObjRef) -> list[ObjRef]:
        """Return all PartDef ObjRefs belonging to a PartitionDef, sorted by index.

        Args:
            partition_ref: ObjRef of the PartitionDef.

        Returns:
            List of PartDef ObjRefs in ascending index order.

        IMPLEMENTATION:
            from cofola.frontend.objects import PartDef
            parts = [(r, defn.index) for r in problem.refs()
                     if isinstance((defn := problem.get_object(r)), PartDef)
                     and defn.partition == partition_ref]
            Return [r for r, _ in sorted(parts, key=lambda x: x[1])]
        """
        parts = []
        for r in self.problem.refs():
            defn = self.problem.get_object(r)
            if isinstance(defn, PartDef) and defn.partition == partition_ref:
                parts.append((r, defn.index))
        return [r for r, _ in sorted(parts, key=lambda x: x[1])]

    def _get_name(self, ref: ObjRef) -> str:
        """Return the user name for ref, or a default 'obj_<id>'.

        Args:
            ref: The object reference.

        Returns:
            Name string.
        """
        return self.problem.get_name(ref) or f"obj_{ref.id}"

    def _obj_pred_name(self, ref: ObjRef) -> str:
        """Derive the WFOMC predicate name for an object reference.

        Format: '<obj_name>' (create_cofola_pred will add the 'p_' prefix).

        Args:
            ref: The object reference.

        Returns:
            Name string for the predicate.
        """
        return self._get_name(ref)

    def _entity_pred_name(self, ref: ObjRef, entity: IREntity) -> str:
        """Derive the entity-specific predicate name.

        Format: '<obj_name>_<entity_name>'

        Args:
            ref: The bag object reference.
            entity: The entity.

        Returns:
            Name string.
        """
        return f"{self._get_name(ref)}_{entity.name}"

    def _obj_var_name(self, ref: ObjRef) -> str:
        """Derive the symbolic variable name for an object.

        Format: '<obj_name>' (create_cofola_var will add the 'v_' prefix).

        Args:
            ref: The object reference.

        Returns:
            Name string.
        """
        return self._get_name(ref)

    def _entity_var_name(self, ref: ObjRef, entity: IREntity) -> str:
        """Derive the per-entity variable name for a bag object.

        Format: '<obj_name>_<entity_name>'

        Args:
            ref: The bag object reference.
            entity: The entity.

        Returns:
            Name string.
        """
        return f"{self._get_name(ref)}_{entity.name}"

    def _indis_var_name(self, ref: ObjRef, multiplicity: int) -> str:
        """Derive the indistinguishable-entity variable name.

        Format: '<obj_name>#<multiplicity>'

        Args:
            ref: The bag object reference.
            multiplicity: The shared multiplicity.

        Returns:
            Name string.
        """
        return f"{self._get_name(ref)}#{multiplicity}"

    def create_pred(self, name: str, arity: int) -> Pred:
        """Create a new WFOMC predicate with the cofola naming convention.

        Args:
            name: The predicate name (will have 'p_' prepended if not present).
            arity: The predicate arity.

        Returns:
            A new Pred.
        """
        return create_cofola_pred(name, arity)

    def create_aux_pred(self, arity: int) -> Pred:
        """Create a unique auxiliary predicate.

        Args:
            arity: The predicate arity.

        Returns:
            A new uniquely-named auxiliary Pred.
        """
        return create_aux_pred(arity)

    def create_var(self, name: str, *, use_gen: bool = True) -> Expr:
        """Create a new symbolic variable with the cofola naming convention.

        Args:
            name: The variable name (will have 'v_' prepended if not present).
            use_gen: If True, append to self.gen_vars (for Decoder).

        Returns:
            A new symbolic Expr.
        """
        var = create_cofola_var(name)
        if use_gen:
            self.gen_vars.append(var)
        return var

    def prune_evidence(self) -> None:
        """Remove evidence irrelevant to both the sentence and weighted output.

        Should be called during build() before constructing EncodedProblem.

        A weighted predicate may disappear from the sentence after constant
        folding while its polynomial degree is still consumed by the decoder.
        Its ground evidence must survive so WFOMC retains that predicate in the
        result polynomial.
        """
        relevant_preds = self.sentence.preds() | self.weighting.keys()
        self.unary_evidence = {
            evidence
            for evidence in self.unary_evidence
            if evidence_parts(evidence)[0] in relevant_preds
        }

    def build(self) -> tuple[EncodedProblem, Decoder]:
        """Finalise encoding and return the (EncodedProblem, Decoder) pair.

        Steps:
        1. Normalize the sentence for the selected WFOMC API generation.
        2. Prune unused evidence: self.prune_evidence()
        3. Rename domain constants with 'c_' prefix (WFOMC convention)
        4. Rename evidence atom arguments with 'c_' prefix
        5. Construct the adapter-owned encoded problem.
        6. Construct Decoder(self.overcount, self.gen_vars,
                              self.validator, self.indis_vars)
        7. Return (wfomc_problem, decoder)

        Returns:
            Tuple of (EncodedProblem, Decoder).
        """
        logger.debug(
            "Context.build: sentence (before normalization):\n  {}",
            self.sentence,
        )
        logger.debug(
            "Context.build: domain: {}",
            sorted(str(c) for c in self.domain),
        )
        logger.debug(
            "Context.build: weighting:\n  {}",
            {str(p): (str(w[0]), str(w[1])) for p, w in self.weighting.items()},
        )
        logger.debug(
            "Context.build: evidence:\n  {}",
            sorted(str(a) for a in self.unary_evidence),
        )
        if self.sentence == top:
            dummy_pred = self.create_aux_pred(1)
            self.sentence = parse(f"\\forall X: (~{dummy_pred}(X))")
        self.sentence = normalize_sentence(self.sentence)
        logger.debug(
            "Context.build: sentence (after normalization):\n  {}",
            self.sentence,
        )
        self.prune_evidence()
        logger.debug(
            "Context.build: evidence (post-prune):\n  {}",
            sorted(str(a) for a in self.unary_evidence),
        )
        new_domain = set()
        new_unary_evidence = set()
        for const in self.domain:
            new_domain.add(Const(f"c_{const.name}"))
        for literal in self.unary_evidence:
            predicate, constant, positive = evidence_parts(literal)
            renamed = predicate(Const(f"c_{constant.name}"))
            new_unary_evidence.add(renamed if positive else ~renamed)
        logger.debug(
            "Context.build: EncodedProblem:\n"
            "  sentence: {}\n"
            "  domain: {}\n"
            "  weighting: {}\n"
            "  evidence: {}",
            self.sentence,
            sorted(str(c) for c in new_domain),
            {str(p): (str(w[0]), str(w[1])) for p, w in self.weighting.items()},
            sorted(str(a) for a in new_unary_evidence),
        )
        wfomc_problem = build_problem(
            self.sentence,
            new_domain,
            self.weighting,
            new_unary_evidence,
        )
        decoder = Decoder(
            self.overcount,
            self.gen_vars,
            self.validator,
            self.indis_vars,
        )
        logger.debug(
            "Context.build: Decoder — overcount={}, gen_vars={}, validator={}, indis_vars={}",
            self.overcount,
            self.gen_vars,
            self.validator,
            self.indis_vars,
        )
        return wfomc_problem, decoder
